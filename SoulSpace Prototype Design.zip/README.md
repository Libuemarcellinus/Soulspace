
  # SoulSpace Prototype Design

  This is a code bundle for SoulSpace Prototype Design. The original project is available at https://www.figma.com/design/X0WiyrfsRLLwsIGvcRUSu3/SoulSpace-Prototype-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  